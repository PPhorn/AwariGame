fsharpc -a AwariSig.fsi AwariLib.fs
fsharpc -r AwariLib.dll Awari.fsx
mono Awari.exe
