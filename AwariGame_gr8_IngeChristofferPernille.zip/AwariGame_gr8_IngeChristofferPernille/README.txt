Awari game
by Christoffer, Inge and Pernille

////////////////////////
Getting started

To start the game follow these steps.
1. Open a terminal
2. Locate the folder Awari
3. When inside the folder run the following
bash CompileAwari.sh

If you are using windows please follow these steps.
1. Open a cmd
2. Locate the folder Awari
3. When inside the folder run the following
fsharpc -a AwariSig.fsi AwariLib.fs
fsharpc -r AwariLib.dll Awari.fsx
Awari.exe

///////////////////////
To compile the game you must have fsharp installed.